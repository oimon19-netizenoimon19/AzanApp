# AzanApp - Islamic Prayer Times & Adhan

## Overview
AzanApp is an Android mobile application that calculates Islamic prayer times and plays the Adhan (call to prayer) at scheduled times. The app is built using Kotlin with Jetpack Compose for the UI and uses the Adhan library for accurate prayer time calculations.

## Project Type
**Android Mobile Application** - This is NOT a web application. It produces an APK file that can be installed on Android devices (API 26+).

## Key Features
- **Accurate Prayer Times**: Calculates Fajr, Dhuhr, Asr, Maghrib, and Isha prayer times using the Karachi calculation method with Hanafi madhab
- **Custom Audio**: Users can select custom audio files for each prayer's Adhan
- **Smart Scheduling**: Automatically schedules alarms for each prayer time with customizable offsets
- **Background Service**: Plays Adhan audio in the background with proper audio focus management
- **Boot Persistence**: Reschedules alarms after device boot or time/timezone changes
- **Retry Mechanism**: Automatically retries failed alarm scheduling

## Tech Stack
- **Language**: Kotlin 1.9.24
- **UI Framework**: Jetpack Compose with Material 3
- **Build System**: Gradle 8.5.2
- **Target SDK**: Android 34 (Android 14)
- **Minimum SDK**: Android 26 (Android 8.0)
- **Key Libraries**:
  - `androidx.compose:compose-bom:2024.09.02` - Jetpack Compose UI
  - `androidx.datastore:datastore-preferences:1.1.1` - Settings storage
  - `com.batoulapps.adhan:adhan:1.2.0` - Prayer times calculation

## Project Structure
```
app/
├── src/main/
│   ├── java/com/abdul/azanapp/
│   │   ├── AzanappActivity.kt        # Main activity with settings UI
│   │   ├── alarm/
│   │   │   ├── AlarmScheduler.kt     # Schedules prayer alarms
│   │   │   ├── PrayerAlarmReceiver.kt # Handles alarm triggers
│   │   │   ├── BootReceiver.kt       # Reschedules on boot
│   │   │   ├── TimeChangeReceiver.kt # Handles time/timezone changes
│   │   │   └── RetryManager.kt       # Retry logic for failed scheduling
│   │   ├── audio/
│   │   │   └── AthanPlaybackService.kt # Audio playback service
│   │   ├── core/
│   │   │   └── PrayerTimesProvider.kt  # Prayer times calculation
│   │   └── store/
│   │       └── SettingsStore.kt       # Settings persistence
│   ├── res/                           # Android resources
│   └── AndroidManifest.xml            # App configuration
└── build.gradle                       # App dependencies
```

## Location Settings
Currently configured for:
- **Location**: Sahiwal, Pakistan (30.6682°N, 73.1114°E)
- **Timezone**: Asia/Karachi
- **Calculation Method**: Karachi
- **Madhab**: Hanafi (for Asr calculation)

## How to Build
Since this is an Android app, it cannot run in a browser. Instead:

1. **Build APK**: Run the Gradle build workflow in Replit to create an APK file
2. **Download APK**: Download the generated APK file from the build output
3. **Install on Android**: Transfer the APK to an Android device and install it

The APK will be generated in: `app/build/outputs/apk/debug/app-debug.apk`

## Development in Replit
- The Replit environment is set up to build the Android APK using Gradle
- Java/Kotlin compilation is supported
- The workflow compiles the project and generates an installable APK
- No emulator/runtime is available - the APK must be deployed to a physical device or external emulator

## Permissions Required
The app requires the following Android permissions:
- `WAKE_LOCK` - Keep device awake during Adhan playback
- `RECEIVE_BOOT_COMPLETED` - Reschedule alarms after boot
- `FOREGROUND_SERVICE_MEDIA_PLAYBACK` - Play Adhan in background
- `SCHEDULE_EXACT_ALARM` - Schedule exact alarm times

## Recent Changes
- **Oct 17, 2025**: Initial project setup in Replit environment
- Configured Java/Gradle build environment
- Set up build workflow for APK generation

## User Preferences
- None specified yet

## Notes
- This is a mobile-only application and requires an Android device to run
- Audio files for Adhan must be selected by the user after installation
- Prayer times are calculated locally on the device, no internet required
