package com.abdul.azanapp.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.abdul.azanapp.store.SettingsStore

class RetryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val attempt = intent.getIntExtra("attempt", 1)
        val ok = try {
            val offsets = SettingsStore(context).offsets()
            AlarmScheduler.scheduleToday(context, offsets)
            true
        } catch (_: Exception) { false }
        if (!ok) RetryManager.scheduleRetry(context, attempt)
    }
}