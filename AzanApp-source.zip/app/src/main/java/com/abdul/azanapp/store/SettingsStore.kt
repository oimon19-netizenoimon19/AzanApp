package com.abdul.azanapp.store

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.abdul.azanapp.alarm.Prayer

class SettingsStore(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun setUri(prayer: Prayer, uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Throwable) {}
        sp.edit().putString("uri_${'$'}{prayer.name}", uri.toString()).apply()
    }

    fun uriFor(prayer: Prayer): Uri? =
        sp.getString("uri_${'$'}{prayer.name}", null)?.let { Uri.parse(it) }

    fun setOffset(prayer: Prayer, minutes: Int) { sp.edit().putInt("off_${'$'}{prayer.name}", minutes).apply() }
    fun offset(prayer: Prayer): Int = sp.getInt("off_${'$'}{prayer.name}", 0)
    fun offsets(): Map<Prayer, Int> = com.abdul.azanapp.alarm.Prayer.values().associateWith { offset(it) }
}