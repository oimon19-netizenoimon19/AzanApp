package com.abdul.azanapp.audio

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.abdul.azanapp.R
import com.abdul.azanapp.alarm.Prayer
import com.abdul.azanapp.store.SettingsStore
import com.abdul.azanapp.AzanappActivity

class AthanPlaybackService : Service() {

    companion object {
        private const val CH_ID = "playback"
        fun start(ctx: Context, prayer: String) {
            val i = Intent(ctx, AthanPlaybackService::class.java).putExtra("prayer", prayer)
            ctx.startForegroundService(i)
        }
    }

    private var player: MediaPlayer? = null
    private lateinit var audioManager: AudioManager
    private lateinit var afr: AudioFocusRequest

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val channel = NotificationChannel(CH_ID, "Playback", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prayer = intent?.getStringExtra("prayer") ?: return START_NOT_STICKY
        startForeground(1, notif("Playing Adhān (${prayer.lowercase().replaceFirstChar { it.uppercase() }})"))

        val uri: Uri = SettingsStore(this).uriFor(Prayer.valueOf(prayer)) ?: return stopSelf().let { START_NOT_STICKY }

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        afr = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { }
            .build()

        val focus = audioManager.requestAudioFocus(afr)
        if (focus != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }

        player = MediaPlayer().apply {
            setAudioAttributes(attrs)
            setDataSource(applicationContext, uri)
            setOnCompletionListener { cleanupStop() }
            setOnPreparedListener { start() }
            setOnErrorListener { _,_,_ -> cleanupStop(); true }
            prepareAsync()
        }

        return START_STICKY
    }

    private fun notif(content: String) = NotificationCompat.Builder(this, CH_ID)
        .setSmallIcon(R.drawable.ic_stat_name)
        .setContentTitle("Azan")
        .setContentText(content)
        .setOnlyAlertOnce(true)
        .setContentIntent(PendingIntent.getActivity(this, 0,
            Intent(this, AzanappActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        .build()

    private fun cleanupStop() {
        try { player?.release() } catch (_: Throwable) {}
        player = null
        try { audioManager.abandonAudioFocusRequest(afr) } catch (_: Throwable) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { cleanupStop(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}