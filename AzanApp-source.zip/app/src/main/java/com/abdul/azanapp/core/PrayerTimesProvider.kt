package com.abdul.azanapp.core

import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.util.*

object PrayerTimesProvider {
    private val coords = Coordinates(30.6682, 73.1114) // Sahiwal
    private val params = CalculationMethod.KARACHI.parameters.apply {
        madhab = Madhab.HANAFI
    }
    fun forDate(date: Calendar): PrayerTimes {
        val dc = DateComponents(date)
        return PrayerTimes(coords, dc, params)
    }
    fun timezone(): TimeZone = TimeZone.getTimeZone("Asia/Karachi")
}