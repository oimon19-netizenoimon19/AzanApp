package com.abdulwahhab.azan.alarm
enum class Prayer { FAJR, DHUHR, ASR, MAGHRIB, ISHA }
