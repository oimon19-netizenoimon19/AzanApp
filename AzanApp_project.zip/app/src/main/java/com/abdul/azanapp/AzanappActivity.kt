package com.abdul.azanapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abdul.azanapp.alarm.AlarmScheduler
import com.abdul.azanapp.alarm.Prayer
import com.abdul.azanapp.audio.AthanPlaybackService
import com.abdul.azanapp.core.PrayerTimesProvider
import com.abdul.azanapp.store.SettingsStore
import java.text.SimpleDateFormat
import java.util.*

class AzanappActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SettingsScreen()
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = this@AzanappActivity
    val ss = remember { SettingsStore(ctx) }
    val tz = PrayerTimesProvider.timezone()
    val cal = Calendar.getInstance(tz)
    val pt = remember { PrayerTimesProvider.forDate(cal) }
    var offsets by remember { mutableStateOf(ss.offsets().toMutableMap()) }

    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()).apply { timeZone = tz } }

    // Document picker launcher
    var pendingPrayer by remember { mutableStateOf<Prayer?>(null) }
    val launcher = remember { 
        (ctx as ComponentActivity).registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { pUri ->
                pendingPrayer?.let { p ->
                    ctx.contentResolver.takePersistableUriPermission(pUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    ss.setUri(p, pUri)
                    Toast.makeText(ctx, "${p.name} audio set", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun pickFor(p: Prayer) {
        pendingPrayer = p
        launcher.launch(arrayOf("audio/*"))
    }

    Column(Modifier.padding(16.dp)) {
        Text("Sahiwal • Karachi Method • Asr: Hanafi", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text("Today", style = MaterialTheme.typography.titleSmall)

        val prayerTimes = listOf(
            Triple(Prayer.FAJR, "Fajr", pt.fajr),
            Triple(Prayer.DHUHR, "Dhuhr", pt.dhuhr),
            Triple(Prayer.ASR, "Asr", pt.asr),
            Triple(Prayer.MAGHRIB, "Maghrib", pt.maghrib),
            Triple(Prayer.ISHA, "Isha", pt.isha),
        )

        prayerTimes.forEach { (p, label, date) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("$label: ${timeFmt.format(date)}")
                    Text("Offset: ${offsets[p] ?: 0} min", style = MaterialTheme.typography.bodySmall)
                }
                Row {
                    Button(onClick = { pickFor(p) }, modifier = Modifier.padding(end = 8.dp)) { Text("Pick audio") }
                    Button(onClick = { AthanPlaybackService.start(ctx, p.name) }) { Text("Play") }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            val ok = try {
                AlarmScheduler.scheduleToday(ctx, offsets)
                true
            } catch (e: Exception) { false }
            if (ok) Toast.makeText(ctx, "Scheduled for today", Toast.LENGTH_SHORT).show()
            else Toast.makeText(ctx, "Schedule failed. Will retry automatically.", Toast.LENGTH_LONG).show()
        }) {
            Text("Apply & Schedule")
        }
    }
}