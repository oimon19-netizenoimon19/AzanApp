package com.abdul.azanapp.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.abdul.azanapp.store.SettingsStore

class TimeChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val ok = try {
            val offsets = SettingsStore(context).offsets()
            AlarmScheduler.scheduleToday(context, offsets)
            true
        } catch (_: Exception) { false }
        if (!ok) RetryManager.scheduleRetry(context, 0)
    }
}