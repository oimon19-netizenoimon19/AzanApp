package com.abdul.azanapp.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.abdul.azanapp.core.PrayerTimesProvider
import java.util.*

enum class Prayer { FAJR, DHUHR, ASR, MAGHRIB, ISHA }

object AlarmScheduler {
    fun scheduleToday(context: Context, offsets: Map<Prayer, Int>) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val tz = PrayerTimesProvider.timezone()
        val cal = Calendar.getInstance(tz)
        val pt = PrayerTimesProvider.forDate(cal)

        fun scheduleOne(prayer: Prayer, timeMillis: Long) {
            val adj = offsets[prayer] ?: 0
            val target = timeMillis + adj * 60_000L
            if (target <= System.currentTimeMillis()) return
            val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                action = "com.yourapp.PLAY_ADHAN"
                putExtra("prayer", prayer.name)
            }
            val pi = PendingIntent.getBroadcast(
                context,
                prayer.ordinal,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pi)
        }

        scheduleOne(Prayer.FAJR,    pt.fajr.time)
        scheduleOne(Prayer.DHUHR,   pt.dhuhr.time)
        scheduleOne(Prayer.ASR,     pt.asr.time)
        scheduleOne(Prayer.MAGHRIB, pt.maghrib.time)
        scheduleOne(Prayer.ISHA,    pt.isha.time)
    }
}