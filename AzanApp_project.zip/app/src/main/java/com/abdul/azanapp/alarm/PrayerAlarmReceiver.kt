package com.abdul.azanapp.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.abdul.azanapp.audio.AthanPlaybackService

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prayer = intent.getStringExtra("prayer") ?: return
        AthanPlaybackService.start(context, prayer)
    }
}